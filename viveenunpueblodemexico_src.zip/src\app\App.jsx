import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import SiteHeader from "../components/layout/SiteHeader/SiteHeader";
import SiteFooter from "../components/layout/SiteFooter/SiteFooter";

import Home from "../pages/Home/Home";
import Estados from "../pages/Estados/Estados";
import Estado from "../pages/Estado/Estado";
import Pueblos from "../pages/Pueblos/Pueblos";
import PuebloDetalle from "../pages/PuebloDetalle/PuebloDetalle";

import PuebloForo from "../pages/PuebloForo/PuebloForo";
import ThreadDetalle from "../pages/PuebloForo/ThreadDetalle";

import AdminLogin from "../pages/Admin/AdminLogin";
import AdminOfertas from "../pages/Admin/AdminOfertas";
import RequireAdmin from "../components/auth/RequireAdmin";
import AdminForo from "../pages/Admin/AdminForo";

import Trabajo from "../pages/Trabajo/Trabajo";
import TrabajoPublicar from "../pages/Trabajo/TrabajoPublicar";
import Vivienda from "../pages/Vivienda/Vivienda";
import Traspasos from "../pages/Traspasos/Traspasos";
import ViviendaPublicar from "../pages/Vivienda/ViviendaPublicar";
import TraspasosPublicar from "../pages/Traspasos/TraspasosPublicar";
import Login from "../pages/Login/Login";
import MisPublicacionesPage from "../pages/MisPublicaciones/MisPublicaciones";
import RequireUser from "../components/auth/RequireUser";

export default function App() {
  return (
    <BrowserRouter>
    <div className="appShell">
      <SiteHeader />
      <Toaster position="top-center" />

       <main className="appMain">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/estados" element={<Estados />} />
        <Route path="/estado/:estadoSlug" element={<Estado />} />

        <Route path="/pueblos" element={<Pueblos />} />
        <Route path="/pueblo/:slug" element={<PuebloDetalle />} />

        <Route path="/pueblo/:slug/foro" element={<PuebloForo />} />
        <Route path="/pueblo/:slug/foro/:threadId" element={<ThreadDetalle />} />

        <Route path="/trabajo" element={<Trabajo />} />
        <Route path="/vivienda" element={<Vivienda />} />
        <Route path="/traspasos" element={<Traspasos />} />
        
        <Route path="/trabajo/publicar" element={<TrabajoPublicar />} />
        <Route path="/vivienda/publicar" element={<ViviendaPublicar />} />
        <Route path="/traspasos/publicar" element={<TraspasosPublicar />} />
        
        <Route
          path="/mis-publicaciones"
          element={
            <RequireUser>
              <MisPublicacionesPage />
            </RequireUser>
          }
        />


        <Route path="/admin/login" element={<AdminLogin />} />
        <Route
          path="/admin/ofertas"
          element={
            <RequireAdmin>
              <AdminOfertas />
            </RequireAdmin>
          }
        />
        <Route
          path="/admin/foro"
          element={
            <RequireAdmin>
              <AdminForo />
            </RequireAdmin>
          }
        />


        <Route
          path="*"
          element={
            <div style={{ padding: 24, fontFamily: "system-ui" }}>
              <h2>No encontrado</h2>
            </div>
          }
        />
      </Routes>     
       </main>

        <SiteFooter />
      </div>
    </BrowserRouter>
  );
}